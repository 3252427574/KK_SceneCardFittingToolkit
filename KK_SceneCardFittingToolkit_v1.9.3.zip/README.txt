# 场景卡套档工具箱 (Scene Card Fitting Toolkit) v1.9.3

Koikatu / Koikatsu 的 CharaStudio 插件。

## 安装

把 `BepInEx` 文件夹里的内容合并到游戏根目录(与 `Koikatu.exe` / `CharaStudio.exe` 同级):

```
游戏根目录/
└── BepInEx/
    └── plugins/
        ├── KK_SceneCardFittingToolkit.dll   ← 插件主文件
        └── KKPEHeightLock/                  ← 资源目录(图标/背景图)
            ├── icon.png                     ← 工具栏图标(可替换,任意尺寸)
            └── background.png               ← 菜单背景图(可替换)
```

> 需要已安装: BepInEx 5、KKAPI、KKPE、KK_MaterialEditor、Timeline、VRGIN_KKCS、KKCharaStudioVRPlugin(Ermin)。

## 功能

- **身高骨骼锁定**: 锁定 `cf_n_height` 缩放,不被动画/姿势覆盖
- **身材保留**: 替换角色时保留体型滑块 / 全部体型参数
- **场景替换角色**: 加载场景后按性别自动替换、随机替换(女/男/全部)
- **场景播放器**: 场景浏览/上一下一/加载/删除,Timeline 控制(播放/暂停/CAM),FSS 子场景
- **服装预设**: 校服1/校服2/体操/泳装/社团/便服/睡衣 一键切换 + 部件三态
- **场景工具**: 一键去无用球体、一键去马赛克(可设加载场景自动执行)
- **VR 第一人称**: 相机跟随选中角色双眼,右手摇杆转头
- **VR 悬浮菜单**: 完整复刻桌面菜单(场景播放器+第一人称/服装预设/场景替换/场景工具+身高+缩放,分页浏览),左手柄 Y 键呼出,右手射线+扳机操作,面板跟随眼前,VR 内可直接选角色卡(缩略图列表)、选子目录、选场景人物

## 配置

配置文件 `BepInEx/config/com.kkpeheightlock.cfg`(首次运行后生成),或游戏内 F1 设置界面调整。

## 使用

- 桌面: 工作室里点左侧工具栏图标(深红菱形)打开菜单。
- VR: 左手柄 Y 键呼出悬浮菜单;`◀ ▶` 按钮翻页;右手射线指向按钮、扳机确认;命中点有青绿色圆环光标。

## 源码

`源码/` 目录包含 `KKPEHeightLock.cs`、`VRFloatingPanel.cs` 和 `KKPEHeightLock.csproj`(net35)。用 dotnet SDK 构建:

```
cd 源码 && dotnet build -c Release
```

---

该插件为完全免费发布,倒狗和贩子全家死光。
